
public abstract class Tile {

	public boolean matches(Tile other) {
		// Check if both references are pointing to the same object
		if (this == other) {
			return true;
		}
		// Check if the object contains values other than null
		if (other == null) {
			return false;
		}
		// Check if both objects are from the same class
		if (getClass() != other.getClass()) { 
			return false;
		}
		return true;
	}
}
