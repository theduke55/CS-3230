
public class SeasonTile extends PictureTile{
	
	// Constructor
	public SeasonTile(String name) {
		super(name);
	}
}
