
public class BambooTile extends RankTile{
	
	// Constructor
	public BambooTile(int rank) {
		super(rank);
	}
	
	public String toString() {
		return "Bamboo " + this.rank;
	}
}
