import java.util.HashMap;

public class CharacterTile extends Tile {
	// Class variable
	protected char symbol;

	// HashMap entry for English characters to Chinese characters
	private static final HashMap<Character, Character> map = new HashMap<>();
	static {
		map.put('1', '\u4E00');
		map.put('2', '\u4E8C');
		map.put('3', '\u4E09');
		map.put('4', '\u56DB');
		map.put('5', '\u4E94');
		map.put('6', '\u516D');
		map.put('7', '\u4E03');
		map.put('8', '\u516B');
		map.put('9', '\u4E5D');
		map.put('N', '\u5317');
		map.put('E', '\u6771');
		map.put('W', '\u897F');
		map.put('S', '\u5357');
		map.put('C', '\u4E2D');
		map.put('F', '\u767C');
	}

	// Constructor
	public CharacterTile(char symbol) {
		this.symbol = symbol;
	}

	public boolean matches(Tile other) {
		// Call the matches method from the Tile class
		if (super.matches(other)) {
			// Create a test object from casting CharacterTile
			CharacterTile test = (CharacterTile) other;
			return test.symbol == this.symbol;
		} else {
			return false;
		}
	}

	public String toString() {
		switch (symbol) {
		case 'C':
			return "Red Dragon";
		case 'F':
			return "Green Dragon";
		case 'N':
			return "North Wind";
		case 'E':
			return "East Wind";
		case 'W':
			return "West Wind";
		case 'S':
			return "South Wind";
		default:
			return "Character " + symbol;
		}
	}

	public String toChinese() {
		String chinese = Character.toString(map.get(symbol));
		return chinese;
	}

}
