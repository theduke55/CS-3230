
public abstract class PictureTile extends Tile{
	// Class variables
	private String name;
	
	// Constructor
	public PictureTile(String name) {
		this.name = name;
	}
	
	public String toString() {
		return name;
	}
}
