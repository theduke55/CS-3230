
public class WhiteDragonTile extends Tile{
	
	public String toString() {
		return "White Dragon";
	}
}
