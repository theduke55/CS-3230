/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CardGame;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

/**
 *
 * @author Trevor Barker
 */
public class DisplayThreeCards extends Application{
    //Build the deck for JavaFX
    Deck deckFX = new Deck();
    
    public static void main(String[] args){
        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        //Shuffle
        deckFX.Shuffle();
        
        //Build the window and create an image object
        Pane hbox = new HBox(5);
        Image card;
        
        //Loop through three times and display the cards image to the hbox
        for(int i = 0; i < 3; i++){
            int value = (deckFX.cards.get(i).getRankValue() + deckFX.cards.get(i).getSuitValue());
            card = new Image("image/" + value + ".png");
            hbox.getChildren().add(new ImageView(card));
        }
        
        Scene scene = new Scene(hbox, 227, 100);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Display 3 Cards");
        primaryStage.show();
    }
    
}
