import java.awt.*;  
import javax.swing.*;

public class Tile extends JPanel implements Cloneable 
{
	public int LAYER;
    public int ROW;         // y coordinate
    public int COLUMN;      // x coordinate
    public int arrX;
    public int arrY;
    public int arrZ;

	public Tile()
	{
		setPreferredSize(new Dimension(101,121));
		setSize(101, 121); 
		setOpaque(false);
	}
	
		public void paintComponent(Graphics g)
		{
			super.paintComponent(g);
			
            Color custom = new Color(252,233,208);//blanchedalmond
            Color custom2 = new Color(255,251,247);//snow
            Color bottom = new Color(32, 178, 170);
            Color bottom2 = new Color(0, 255, 0);//Green 
            Color bottom3 = new Color(20, 185, 120);
            //Dark Green 0, 139, 0
            //Other Dark Green 1, 145, 102
            
            g.drawRect(25, 0, 75, 75);
            
            Graphics2D g2 = (Graphics2D)g;
            
            Polygon polFill0 = new Polygon();
            polFill0.addPoint(24, 0);
            polFill0.addPoint(11,26);
            polFill0.addPoint(11,99);
            polFill0.addPoint(24,74);
            
            Polygon polFill1 = new Polygon();
            polFill1.addPoint(25, 75);
            polFill1.addPoint(10,100);
            polFill1.addPoint(85,100);
            polFill1.addPoint(100,75);
            
            Polygon polFill2 = new Polygon();
            polFill2.addPoint(9, 26);
            polFill2.addPoint(1,46);
            polFill2.addPoint(1,119);
            polFill2.addPoint(9,99);
            
            Polygon polFill3 = new Polygon();
            polFill3.addPoint(1,120);
            polFill3.addPoint(10,101);
            polFill3.addPoint(84,101);
            polFill3.addPoint(74,120);
            
            GradientPaint grad = new GradientPaint(25, 0, custom, 100, 75, custom2);
            g2.setPaint(grad);
            g.fillRect(26,1, 73 ,73);
            
           
            g2.fill(polFill0);
            g2.fill(polFill1);
               
            GradientPaint grad1 = new GradientPaint(0, 115, bottom, 0, 45, bottom3);
            g2.setPaint(grad1);
            g2.fill(polFill2);
            GradientPaint grad2 = new GradientPaint(0, 115, bottom, 80, 100, bottom2);
            g2.setPaint(grad2);
            g2.fill(polFill3);  
            
            g.setColor(Color.BLACK);
            
            Polygon p0 = new Polygon();
            p0.addPoint(25,0);
            p0.addPoint(10,25);
            p0.addPoint(10,100);
            p0.addPoint(25,75);
            g.drawPolygon(p0);
            
            Polygon p1 = new Polygon();
            p1.addPoint(25,75);
            p1.addPoint(10,100);
            p1.addPoint(85,100);
            p1.addPoint(100,75);
            g.drawPolygon(p1);
            
            Polygon p2 = new Polygon();
            p2.addPoint(10,25);
            p2.addPoint(0,45);
            p2.addPoint(0,120);
            p2.addPoint(10,100);
            g.drawPolygon(p2);
            
            Polygon p3 = new Polygon();
            p3.addPoint(0,120);
            p3.addPoint(10,100);
            p3.addPoint(85,100);
            p3.addPoint(75,120);
            g.drawPolygon(p3);
		}

	public boolean matches(Tile other)
	{
		if (getClass() != other.getClass())
		{
			return false; 
		} 
		else
		{
			return true; 
		}
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException
	{
		return super.clone();
	}
	
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Tile");

		frame.add(new Tile());

		frame.pack();
		frame.setVisible(true);
	}
}

