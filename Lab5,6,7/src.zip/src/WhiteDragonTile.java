import java.awt.*;  
import javax.swing.*;

public class WhiteDragonTile extends Tile
{
	public WhiteDragonTile()
	{
		setToolTipText(toString());
	}
	public String toString()
	{
		return "White Dragon";
	}
	 
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);
		
		Graphics2D g2 = (Graphics2D) g;
		g2.setColor(Color.BLUE);
		
		g2.fillRect(37, 12, 8, 5);
		g2.setColor(Color.WHITE);
		g2.fillRect(45, 12, 8, 5);
		g2.setColor(Color.BLUE);
		g2.fillRect(53, 12, 8, 5);
		g2.setColor(Color.WHITE);
		g2.fillRect(61, 12, 8, 5);
		g2.setColor(Color.BLUE);
		g2.fillRect(69, 12, 8, 5);
		g2.setColor(Color.WHITE);
		g2.fillRect(77, 12, 8, 5);//End of First Line 
		g2.setColor(Color.BLUE);
		g2.fillRect(80, 17, 5,8);
		g2.setColor(Color.WHITE);
		g2.fillRect(80, 26, 5, 8);
		g2.setColor(Color.BLUE);
		g2.fillRect(80, 33, 5, 8);
		g2.setColor(Color.WHITE);
		g2.fillRect(80, 40, 5, 8);
		g2.setColor(Color.BLUE);
		g2.fillRect(80, 47, 5, 8);
		g2.setColor(Color.WHITE);
		g2.fillRect(77, 55, 8, 5);//
		g2.setColor(Color.BLUE);
		g2.fillRect(69, 55, 8, 5);
		g2.setColor(Color.WHITE);
		g2.fillRect(61, 55, 8, 5);
		g2.setColor(Color.BLUE);
		g2.fillRect(53, 55, 8, 5);
		g2.setColor(Color.WHITE);
		g2.fillRect(45, 55, 8, 5);
		g2.setColor(Color.BLUE);
		g2.fillRect(37, 55, 8, 5);
		g2.setColor(Color.WHITE);
		g2.fillRect(37, 47, 5, 8);//Left Side Corner 
		g2.setColor(Color.BLUE);
		g2.fillRect(37, 40, 5, 8);
		g2.setColor(Color.WHITE);
		g2.fillRect(37, 32, 5, 8);
		g2.setColor(Color.BLUE);
		g2.fillRect(37, 24, 5, 8);
		g2.setColor(Color.WHITE);
		g2.fillRect(37, 17, 5, 8);
		g2.setColor(Color.BLUE);
		g2.drawRect(37, 12, 48, 48);
		g2.setColor(Color.BLUE);
		g2.drawRect(42, 17, 37, 37);
		
	}
	
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("White Dragon Tile");

		frame.add(new WhiteDragonTile());

		frame.pack();
		frame.setVisible(true);
	}
}




