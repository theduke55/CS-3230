import java.awt.*;
import java.net.URL;

import javax.swing.*;
import java.awt.*;
import java.util.*;

import java.awt.event.*;
import java.net.*; 
import javax.swing.border.*;

public class SeasonTile extends PictureTile
{
	private ImageIcon image; 
	
	public SeasonTile(String name)
	{
		super(name);
		
		switch(name)
		{
			case "Spring" : 
				 URL url = MahJong.class.getResource("images/Spring.png");
		         image = new ImageIcon(url);
				break; 
			case "Summer" : 
				URL url1 = MahJong.class.getResource("images/Summer.png");
		        image = new ImageIcon(url1);
				break; 
			case "Fall" : 
				URL url2 = MahJong.class.getResource("images/Fall.png");
		        image = new ImageIcon(url2);
				break; 
			case "Winter" : 
				URL url3 = MahJong.class.getResource("images/Winter.png");
		        image = new ImageIcon(url3);
				break; 
		}
		setToolTipText(toString());
	}
	
	//@Override 
	public void paintComponent(Graphics g)
	{
		
		super.paintComponent(g);
		
		g.drawImage(image.getImage(), 35, 10, this);
	
	}
	
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Season Tiles");

		frame.add(new SeasonTile("Spring"));
		frame.add(new SeasonTile("Summer"));
		frame.add(new SeasonTile("Fall"));
		frame.add(new SeasonTile("Winter"));

		frame.pack();
		frame.setVisible(true);
	}
}
