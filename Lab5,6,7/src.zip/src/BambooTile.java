import java.awt.*;
import javax.swing.*;

public class BambooTile extends RankTile
{
	private Bamboo[] bamboos; 
	protected int centerX = 65, 
				  centerY = 35; 
	
	public BambooTile(int rank)
	{
		super(rank); 
		setToolTipText(toString());
		bamboos = new Bamboo[rank];
		
		switch(rank)
		{
			case 2: 
				bamboos[0] = new Bamboo(centerX, centerY-13, Color.BLUE);
				bamboos[1] = new Bamboo(centerX, centerY+13, Color.GREEN);
				break;
			case 3: 
				bamboos[0] = new Bamboo(centerX, centerY-13, Color.BLUE);
				bamboos[1] = new Bamboo(centerX-10, centerY+13, Color.GREEN);
				bamboos[2] = new Bamboo(centerX+10, centerY+13, Color.GREEN);
				break;
			case 4: 
				bamboos[0] = new Bamboo(centerX-10, centerY-13, Color.BLUE);
				bamboos[1] = new Bamboo(centerX+10, centerY-13, Color.GREEN);
				bamboos[2] = new Bamboo(centerX-10, centerY+13, Color.GREEN);
				bamboos[3] = new Bamboo(centerX+10, centerY+13, Color.BLUE);
				break;
			case 5: 
				bamboos[0] = new Bamboo(centerX-15, centerY-13, Color.GREEN);
				bamboos[1] = new Bamboo(centerX+15, centerY-13, Color.BLUE);
				bamboos[2] = new Bamboo(centerX, centerY, Color.RED);
				bamboos[3] = new Bamboo(centerX-15, centerY+13, Color.BLUE);
				bamboos[4] = new Bamboo(centerX+15, centerY+13, Color.GREEN);
				break;
			case 6: 
				bamboos[0] = new Bamboo(centerX-15, centerY+13, Color.GREEN);
				bamboos[1] = new Bamboo(centerX+15, centerY+13, Color.GREEN);
				bamboos[2] = new Bamboo(centerX, centerY+13, Color.GREEN);
				bamboos[3] = new Bamboo(centerX-15, centerY-13, Color.BLUE);
				bamboos[4] = new Bamboo(centerX, centerY-13, Color.BLUE);
				bamboos[5] = new Bamboo(centerX+15, centerY-13, Color.BLUE);
				break;
			case 7: 
				bamboos[0] = new Bamboo(centerX-15, centerY+26, Color.GREEN);
				bamboos[1] = new Bamboo(centerX+15, centerY+26, Color.GREEN);
				bamboos[2] = new Bamboo(centerX, centerY+26, Color.BLUE);
				bamboos[3] = new Bamboo(centerX-15, centerY, Color.GREEN);
				bamboos[4] = new Bamboo(centerX, centerY, Color.BLUE);
				bamboos[5] = new Bamboo(centerX+15, centerY, Color.GREEN);
				bamboos[6] = new Bamboo(centerX, centerY-24, Color.RED);
				break;
			case 8: 
				bamboos[0] = new Bamboo(centerX-25, centerY-10, Color.GREEN);
				bamboos[1] = new RotatedBamboo(centerX-5, centerY-42, Color.GREEN, 30);
				bamboos[2] = new RotatedBamboo(centerX-23, centerY+29, Color.GREEN, -38);
				bamboos[3] = new Bamboo(centerX+25, centerY-10, Color.GREEN);
				bamboos[4] = new Bamboo(centerX-25, centerY+20, Color.BLUE);
				bamboos[5] = new RotatedBamboo(centerX-40, centerY+38, Color.BLUE, -26);
				bamboos[6] = new RotatedBamboo(centerX+25, centerY-18, Color.BLUE, 26);
				bamboos[7] = new Bamboo(centerX+25, centerY+20, Color.BLUE);
				break;
			case 9: 
				bamboos[0] = new Bamboo(centerX-15, centerY+26, Color.RED);
				bamboos[1] = new Bamboo(centerX+15, centerY+26, Color.GREEN);
				bamboos[2] = new Bamboo(centerX, centerY+26, Color.BLUE);
				bamboos[3] = new Bamboo(centerX-15, centerY, Color.RED);
				bamboos[4] = new Bamboo(centerX, centerY, Color.BLUE);
				bamboos[5] = new Bamboo(centerX+15, centerY, Color.GREEN);
				bamboos[6] = new Bamboo(centerX-15, centerY-24, Color.RED);
				bamboos[7] = new Bamboo(centerX, centerY-24, Color.BLUE);
				bamboos[8] = new Bamboo(centerX+15, centerY-24, Color.GREEN);	
				break;
			default: 
				 System.err.println("Invalid tile");
	             break;
		}
	}
	
	public void paintComponent(Graphics g)
	{
		super.paintComponent(g);

		for (Bamboo b : bamboos)
			if (b != null)
				b.draw(g);
	}
	
	@Override public String toString()
	{
		return "Bamboo " + rank; 
	}
	
	public class Bamboo
	{
		private int x; 
		private int y; 
		private Color color; 
		
		public Bamboo(int x, int y, Color color)
		{
			this.x = x; 
			this.y = y; 
			this.color = color; 
		}
		
		public void draw(Graphics g)
		{
			Graphics2D g2 = (Graphics2D) g;
			
			Polygon shape = new Polygon();
			int one = 1;
			int two = 2; 
			int three = 3;
			int four = 4;
			int five = 5; 
			int six = 6;
			int seven = 7;
			int eight = 8; 
			int nine = 9;
			int eleven = 11; 
			
	        shape.addPoint(x-3, y-9);
	        shape.addPoint(x+3, y-9);
	        shape.addPoint(x+4, y-8);
	        shape.addPoint(x+4, y-6);
	        shape.addPoint(x+3, y-6);
	        shape.addPoint(x+2, y-5);
	        shape.addPoint(x+2, y-2);
	        shape.addPoint(x+4, y+1);
	        shape.addPoint(x+4, y+3);
	        shape.addPoint(x+3, y+3);
	        shape.addPoint(x+2, y+4);
	        shape.addPoint(x+2, y+7);
	        shape.addPoint(x+4, y+9);
	        shape.addPoint(x+4, y+11);
	        shape.addPoint(x-4, y+11);
	        shape.addPoint(x-4, y+9);
	        shape.addPoint(x-2, y+7);
	        shape.addPoint(x-2, y+4);
	        shape.addPoint(x-3, y+3);
	        shape.addPoint(x-4, y+3);
	        shape.addPoint(x-4, y);
	        shape.addPoint(x-2, y-1);
	        shape.addPoint(x-2, y-6);
	        shape.addPoint(x-3, y-6);
	        shape.addPoint(x-4, y-7);
	        shape.addPoint(x-4, y-8);

	        g2.setColor(color);
	        g2.fillPolygon(shape);
	        g2.setColor(Color.WHITE);
	        g2.drawLine(x, y-1, x, y-6);
	        g2.drawLine(x, y+3, x, y+9);
		}
	}
	
	public class RotatedBamboo extends Bamboo
	{
		private int x;
	    private int y;
	    private int angle;
	    
		public RotatedBamboo(int x, int y, Color color, int angle)
		{
			super(x,y,color);
			this.x = x; 
			this.y = y; 
			this.angle = angle;
		}
		
		public void draw(Graphics g)
	    {		
			
			Graphics2D g2 = (Graphics2D) g;
	        
			g2.rotate(Math.toRadians(angle));
	          
	        super.draw(g);
	        
	        g2.rotate(Math.toRadians(-angle));
	    }

	}
	
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Bamboo Tiles");

		frame.add(new BambooTile(2));
		frame.add(new BambooTile(3));
		frame.add(new BambooTile(4));
		frame.add(new BambooTile(5));
		frame.add(new BambooTile(6));
		frame.add(new BambooTile(7));
		frame.add(new BambooTile(8));
		frame.add(new BambooTile(9));

		frame.pack();
		frame.setVisible(true);
	}
}
