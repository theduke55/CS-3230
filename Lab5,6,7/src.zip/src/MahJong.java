import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MahJong extends JFrame
{
	 MahJongBoard board;
	 MahJong main;
	 int gameSeed;
	 ScrollDemo scroll = new ScrollDemo(); 
	 JMenuItem soundToggled;
	 public boolean sound; 

    public MahJong()
    {
    	gameSeed = (int) System.currentTimeMillis() % 100000; 
    	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        double width = screenSize.getWidth();
        double height = screenSize.getHeight();
        setTitle("MahJong Game ID: " + gameSeed);
        board = new MahJongBoard(this, gameSeed);
        makeMenu(); 
        main = this;
        add(board, BorderLayout.CENTER);
        add(scroll, BorderLayout.EAST);
        
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        
        addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0); 
			}
		}); 
        
        setSize((int)width, (int)height);
        setVisible(true);
    }
    
    public void exit()
    {
        if (JOptionPane.showConfirmDialog(this,
                "Do you want to end this program?", "End Program",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            System.exit(0);
    }
    
    public void winner()
    {
    	remove(scroll);
    }
    
    public void makeMenu()
    {
    	JMenuBar menuBar = new JMenuBar(); 
    	setJMenuBar(menuBar);
    	JMenu gameMenu = new JMenu("Game");
    	gameMenu.setMnemonic('G');
    	menuBar.add(gameMenu);
    	
    	//Play New Game
        JMenuItem	play = new JMenuItem("Play New Game", 'P');
        play.setToolTipText("Start New MahJong game");
        play.addActionListener(new ActionListener()
        { public void actionPerformed(ActionEvent e)
            {
                if(JOptionPane.showConfirmDialog(main, "Are you sure you want to start " +
                        "a new game?", "New Game", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
                {
                    remove(board);
                    gameSeed = (int) System.currentTimeMillis() % 100000;
                    main.setTitle("MahJong (Game ID: " + gameSeed + ")");
                    board = new MahJongBoard(main, gameSeed);
                    add(board, BorderLayout.CENTER);
                    add(scroll, BorderLayout.EAST);
                    repaint();
                    revalidate();
                }
            }
        });
        play.setAccelerator(KeyStroke.getKeyStroke("ctrl P"));
        gameMenu.add(play);
        
        // Restarting Current Game
        JMenuItem	restartGame = new JMenuItem("Restart", 'R');
        restartGame.setToolTipText("Restart the current game");
        restartGame.addActionListener(new ActionListener()
        { public void actionPerformed(ActionEvent e)
        {
            if(JOptionPane.showConfirmDialog(main, "Are you sure you want to restart the current game?",
                    "Restart Current Game", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION)
            {
                remove(board);
                main.setTitle("MahJong (Game ID: " + gameSeed + ")");
                board = new MahJongBoard(main, gameSeed);
                add(board, BorderLayout.CENTER);
                add(scroll, BorderLayout.EAST);
                repaint();
                revalidate();
            }
        }
        });
        
        restartGame.setAccelerator(KeyStroke.getKeyStroke("ctrl R"));
        gameMenu.add(restartGame);
        
        //Play a Numbered Game
        JMenuItem	numberedGame = new JMenuItem("Numbered Game", 'N');
        numberedGame.setToolTipText("Play a numbered game");
        numberedGame.addActionListener(new ActionListener()
        { public void actionPerformed(ActionEvent e)
        {
            String input = JOptionPane.showInputDialog(main, "Enter the game number you would like to play. ",
                     "Choose game number to play", JOptionPane.QUESTION_MESSAGE);
            try {
                int gameNum = Integer.parseInt(input);
                remove(board);
                gameSeed = gameNum;
                main.setTitle("MahJong Game ID: " + gameSeed);
                board = new MahJongBoard(main, gameSeed);
                add(board, BorderLayout.CENTER);
                add(scroll, BorderLayout.EAST);
                repaint();
                revalidate();
            }
            catch(NumberFormatException nfe)
            {
                JOptionPane.showMessageDialog(main, "Error! You entered an invalid game number. Has to be a number.",
                        "Invalid Game Number", JOptionPane.ERROR_MESSAGE);
            }
        }
        });
        numberedGame.setAccelerator(KeyStroke.getKeyStroke("ctrl N"));
        gameMenu.add(numberedGame);
        
        //Toggle Sound On/Off
        JMenu	soundMenu = new JMenu("Sound");
        soundMenu.setMnemonic('S');
        menuBar.add(soundMenu);
        //JMenuItem	on = new JMenuItem("Turn Off", 'T');
        //on.setToolTipText("Turn sound on");
        //soundMenu.add(on);
        soundToggled = new JMenuItem("Turn Off", 'T');
        soundToggled.setToolTipText("Toggle Sound");
        soundToggled.addActionListener(new ActionListener()
        { public void actionPerformed(ActionEvent e)
        {
            toggleSound();
        }});
        soundToggled.setAccelerator(KeyStroke.getKeyStroke("ctrl S"));
        soundMenu.add(soundToggled);
        
        // Undo move
        JMenu	moveMenu = new JMenu("Move");
        moveMenu.setMnemonic('M');
        menuBar.add(moveMenu);
        JMenuItem	undo = new JMenuItem("Undo", 'Z');
        undo.setToolTipText("Undo last move");
        undo.addActionListener(new ActionListener()
        { public void actionPerformed(ActionEvent e)
        {
            board.undo();
        }});
        undo.setAccelerator(KeyStroke.getKeyStroke("ctrl Z"));
        moveMenu.add(undo);

        // Redo move
        JMenuItem	redo = new JMenuItem("Redo", 'D');
        redo.setToolTipText("Redo undone move");
        redo.addActionListener(new ActionListener()
        { public void actionPerformed(ActionEvent e)
        {
            board.redo();
        }});
        redo.setAccelerator(KeyStroke.getKeyStroke("ctrl D"));
        moveMenu.add(redo);

        //Help menu
        JMenu	helpMenu = new JMenu("Help");
        helpMenu.setMnemonic('H');
        menuBar.add(helpMenu);
        // Game Operation menu item
        JMenuItem	operation = new JMenuItem("Operation", 'O');
        operation.setToolTipText("Game Operations");
        operation.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                Help h = new Help("Help/help.html", "Help");
                h.display();
            }
        });
        operation.setAccelerator(KeyStroke.getKeyStroke("ctrl O"));
        helpMenu.add(operation);
        JMenuItem	rules = new JMenuItem("Game Rules", 'U');
        rules.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                Help h = new Help("Help/rules.html", "Help");
                h.display();
            }
        });
        rules.setAccelerator(KeyStroke.getKeyStroke("ctrl G"));
        rules.setToolTipText("Click to learn game rules");
        helpMenu.add(rules);

    }
    
    public ScrollDemo getScroll()
    {
        return scroll;
    }
    
    public boolean getSound()
    {
        return sound;
    }

    private void toggleSound()
    {
        sound = !sound;
        soundToggled.setText(sound ? "Turn Off" : "Turn On");
    }
    
    public static void main(String[] args)
    {
    	new MahJong(); 
    }
}
