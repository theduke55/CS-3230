import java.awt.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import java.net.*; 
import javax.swing.border.*;

public class MahJongBoard extends JPanel implements MouseListener
{
	private MahJongModel model;
	private MahJong main; 
	
    private ArrayList<Tile> deck = new ArrayList<>();
    private Tile[][][] array;
    
    private ImageIcon image;
    ScrollDemo scroll;
    PlayClip clip = new PlayClip("audio/stone-scraping.wav", true);
    private Tile first = null;
    private Tile second = null;
    private	Border	normal = BorderFactory.createEmptyBorder();	// border of unselected tile
    private ArrayList<Tile> removedTiles = new ArrayList<>();
    private ArrayList<Tile> undoneTiles = new ArrayList<>();

    
    //This creates a nice frame.
    Border raisedbevel = BorderFactory.createRaisedBevelBorder();
    Border loweredbevel = BorderFactory.createLoweredBevelBorder();
    Border redline = BorderFactory.createLineBorder(Color.BLUE);
    Border compound = BorderFactory.createCompoundBorder(
            raisedbevel, loweredbevel);
    
    private	Border	selected = BorderFactory.createCompoundBorder(
            redline, compound);	// border of selected tile

    public MahJongBoard(MahJong main, int seed)
    {
    	this.main = main;
    	model = new MahJongModel(seed);
    	scroll = (ScrollDemo)main.getScroll();
    	setBackground(Color.decode("#ffe316"));
    	deck = model.getTiles();
    	array = model.getArray();
    	removedTiles.clear();
    	setLayout(null);
        
        int i = 0;
        while(!deck.isEmpty())
        {
            Tile t = deck.remove(i);

            // Add MouseListener to each tile
            t.addMouseListener(this);

            add(t).setLocation(t.COLUMN, t.ROW);
            t.setOpaque(false);
        }
        
        	//Dragon Background 
            URL url = MahJong.class.getResource("images/dragon_bg.png");
            image = new ImageIcon(url);
    }  
    
    public void mousePressed(MouseEvent e)
    {
        Tile tile = (Tile)e.getSource();   
        
        if(first == null)
        {
        	first = tile; 
        	
        	if(model.isTileOpen(first)) 
        	{
                first.setBorder(selected);
            }
            else 
            {
            	first = null;
            }
            return;
        }
        
        // deselect the clicked tile
        else if (tile == first)							
        {
            first.setBorder(normal);
            first = null;
            return;
        }
        
        second = tile; 
        
        if(model.isTileOpen(second))
        {
        	if(first.matches(second))
        	{
        		if (e.getButton() == MouseEvent.BUTTON1) 
        		{
                    Tile t1 = first;
                    Tile t2 = second;
                    Tile t3, t4;
                    try 
                    {
                        t3 = (Tile) t1.clone();
                        t4 = (Tile) t2.clone();
                    }
                    catch(CloneNotSupportedException cnse)
                    {
                        t3 = t1;
                        t4 = t2;
                    }
                    
                    undoneTiles.clear();
                    t1.setVisible(false);
                    t2.setVisible(false);
                    
                    try {
                        if(main.sound) {
                            clip.play();
                            Thread.sleep(500);
                            clip.play();
                        }
                    }
                    catch (InterruptedException ie) {}
                    
                    removedTiles.add(t1);
                    removedTiles.add(t2);
                    t3.setBorder(normal);
                    t4.setBorder(normal);
                    scroll.addToUndo(t3, t4);
                    
                    model.removeArrElement(t1.arrX, t1.arrY, t1.arrZ);
                    model.removeArrElement(t2.arrX, t2.arrY, t2.arrZ);
                    array[t1.arrZ][t1.arrY][t1.arrX] = null;
                    array[t2.arrZ][t2.arrY][t2.arrX] = null;
                    
                    repaint();
                    revalidate();
                    if(removedTiles.size() >= 144)
                        youWin();
        		}
        		else 
        		{
                    first.setBorder(normal);
                    first = second;
                    first.setBorder(selected);
                    second = null;
                    return;
                }
        		
                first.setBorder(normal);
                second.setBorder(normal);
                first = null;
                second = null;
        	}
            else 
            {
            	second = null;
            }
        }
    
    }

    public void mouseReleased(MouseEvent e) {}
    public void mouseClicked(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}
    
    //Methods to help with undoing and redoing moves 
    public void undo()
    {
        try {
            try {
                scroll.removeFromScroll();
                scroll.removeFromScroll();

            }
            catch(EmptyStackException est){}
            Tile t2 = removedTiles.remove(removedTiles.size() - 1);
            undoneTiles.add(t2);
            Tile t1 = removedTiles.remove(removedTiles.size() - 1);
            undoneTiles.add(t1);
            model.addArrElement(t1);
            model.addArrElement(t2);
            array[t1.arrZ][t1.arrY][t1.arrX] = t1;
            array[t2.arrZ][t2.arrY][t2.arrX] = t2;
            t2.setVisible(true);
            t1.setVisible(true);
            repaint();
            revalidate();
        }
        catch(NullPointerException npe){}
        catch(IndexOutOfBoundsException bounds){}
    }

    public void redo()
    {
        Tile t1, t2;
        try {
            //Tile t1, t2;
            t1 = undoneTiles.remove(undoneTiles.size() - 1);
            removedTiles.add(t1);
            t2 = undoneTiles.remove(undoneTiles.size() - 1);
            removedTiles.add(t2);
            model.removeArrElement(t1.arrX, t1.arrY, t1.arrZ);
            model.removeArrElement(t2.arrX, t2.arrY, t2.arrZ);
            array[t1.arrZ][t1.arrY][t1.arrX] = null;
            array[t2.arrZ][t2.arrY][t2.arrX] = null;
            t1.setVisible(false);
            t2.setVisible(false);
            Tile t3, t4;
            try {
                t3 = (Tile) t1.clone();
                t4 = (Tile) t2.clone();
            }
            catch(CloneNotSupportedException cnse)
            {
                t3 = t1;
                t4 = t2;
            }
            scroll.addToUndo(t3, t4);
        }
        catch(NullPointerException npe){}
        catch(IndexOutOfBoundsException bounds){}
    }
    
    public void youWin()
    {
        main.winner();
        Fireworks f = new Fireworks(this);
        f.setSound(main.sound);
        f.setExplosions(10, 1000);
        f.fire();

    }
    
    public ArrayList<Tile> getRemovedTiles()
    {
        return removedTiles;
    }
    
	public void paintComponent(Graphics g)
	{
		
		super.paintComponent(g);
		
		//Positioning the Dragon Background Picture 
		g.drawImage(image.getImage(),400,200, this);
	
	}
	
}    
