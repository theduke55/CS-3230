import java.util.ArrayList; 
import java.util.*;

public class MahJongModel 
{
	private static ArrayList<Tile> tiles;
    private static Tile[][][] array;

    public MahJongModel(int seed)
    {
        tiles = new ArrayList<>();
        array = new Tile[6][8][17]; //z(Layer),y(Column),x(row) 
        createTiles(seed);
    }
    
    public static void createTiles(int seed)
    {
        //Creating 4 of each tile 
        for(int i = 0; i < 4; i++)
        {
            tiles.add(new CharacterTile('1'));
            tiles.add(new CharacterTile('2'));
            tiles.add(new CharacterTile('3'));
            tiles.add(new CharacterTile('4'));
            tiles.add(new CharacterTile('5'));
            tiles.add(new CharacterTile('6'));
            tiles.add(new CharacterTile('7'));
            tiles.add(new CharacterTile('8'));
            tiles.add(new CharacterTile('9'));
            tiles.add(new CharacterTile('N'));
            tiles.add(new CharacterTile('E'));
            tiles.add(new CharacterTile('W'));
            tiles.add(new CharacterTile('S'));
            tiles.add(new CharacterTile('C'));
            tiles.add(new CharacterTile('F'));
            tiles.add(new WhiteDragonTile());

            tiles.add(new Bamboo1Tile());
            tiles.add(new BambooTile(2));
            tiles.add(new BambooTile(3));
            tiles.add(new BambooTile(4));
            tiles.add(new BambooTile(5));
            tiles.add(new BambooTile(6));
            tiles.add(new BambooTile(7));
            tiles.add(new BambooTile(8));
            tiles.add(new BambooTile(9));

            tiles.add(new CircleTile(1));
            tiles.add(new CircleTile(2));
            tiles.add(new CircleTile(3));
            tiles.add(new CircleTile(4));
            tiles.add(new CircleTile(5));
            tiles.add(new CircleTile(6));
            tiles.add(new CircleTile(7));
            tiles.add(new CircleTile(8));
            tiles.add(new CircleTile(9));
        }
            //Adding Flower tiles
	        tiles.add(new FlowerTile("Chrysanthemum"));
	        tiles.add(new FlowerTile("Orchid"));
	        tiles.add(new FlowerTile("Plum"));
	        tiles.add(new FlowerTile("Bamboo"));
	        //Adding Season Tiles 
	        tiles.add(new SeasonTile("Spring"));
	        tiles.add(new SeasonTile("Summer"));
	        tiles.add(new SeasonTile("Fall"));
	        tiles.add(new SeasonTile("Winter"));
	       
	        // shuffles the tiles list with random seed 
	        Collections.shuffle(tiles, new Random(seed));    
	        
	        // i->layer, j->row, k->column
	        int counter = 0;
	        for(int i = 4; i >= 0; i--) //layer
	        {
	            for(int j = 0; j < 8; j++)  //row
	            {
	            	//if you go too far in the layer 
	                if(i == 3 && j == 2) break;	
	                else if(i == 2 && j == 4) break;
	                else if(i == 1 && j == 6) break;
	                for(int k = 0; k < 15; k++) //column
	                {
	                    positionTile(tiles.get(counter), i, j, k);
	                    counter++;
	                    if(i == 4) break;
	                    else if(i == 3 && k == 1) break;
	                    else if(i == 2 && k == 3) break;
	                    else if(i == 1 && k == 5) break;
	                    else if(i == 0 && j == 0 && k > 10) break;
	                    else if(i == 0 && j == 1 && k > 6) break;
	                    else if(i == 0 && j == 2 && k > 8) break;
	                    else if(i == 0 && j == 3 && k > 11) break;      // special case row
	                    else if(i == 0 && j == 4 && k > 12) break;      // special case row
	                    else if(i == 0 && j == 5 && k > 8) break;
	                    else if(i == 0 && j == 6 && k > 6) break;
	                    else if(i == 0 && j == 7 && k > 10) break;
	                }
	                if(i == 4) break;
	            }
	        }

	        // Populate the array
	        counter = 0;
	        for(int i = 4; i >= 0; i--) //layer
	        {
	            for(int j = 0; j < 8; j++)  //row
	            {
	                if(i == 3 && j == 2) break;
	                else if(i == 2 && j == 4) break;
	                else if(i == 1 && j == 6) break;
	                for(int k = 1; k <= 16; k++) //column
	                {
	                    putInArray(tiles.get(counter), i, j, k);
	                    counter++;
	                    if(i == 4) break;
	                    else if(i == 3 && k == 2) break;
	                    else if(i == 2 && k == 4) break;
	                    else if(i == 1 && k == 6) break;
	                    else if(i == 0 && j == 0 && k > 11) break;
	                    else if(i == 0 && j == 1 && k > 7) break;
	                    else if(i == 0 && j == 2 && k > 9) break;
	                    else if(i == 0 && j == 3 && k > 12) break;      // special case row
	                    else if(i == 0 && j == 4 && k > 13) break;      // special case row
	                    else if(i == 0 && j == 5 && k > 9) break;
	                    else if(i == 0 && j == 6 && k > 7) break;
	                    else if(i == 0 && j == 7 && k > 11) break;
	                }
	                if(i == 4) break;
	            }
	        }     
    }
    
    public static void putInArray(Tile t, int z, int y, int x)
    {
    	t.arrZ = z;
        if(z == 4)
        {
            t.arrY = y + 3;
            t.arrX = x + 6;
            array[z][y + 3][x + 6] = t;
        }
        else if(z == 3)
        {
            t.arrY = 4 - y;
            t.arrX = x + 6;
            array[z][4 - y][x + 6] = t;
        }
        else if(z == 2)
        {
            t.arrY = 5 - y;
            t.arrX = x + 5;
            array[z][5 - y][x + 5] = t;
        }
        else if(z == 1)
        {
            t.arrY = 6 - y;
            t.arrX = x + 4;
            array[z][6 - y][x + 4] = t;
        }
        else
        {
            switch(y)
            {
                case 0:
                    t.arrY = 7;
                    t.arrX = x + 1;
                    array[z][7][x + 1] = t;
                    break;
                case 1:
                    t.arrY = 6;
                    t.arrX = x + 3;
                    array[z][6][x + 3] = t;
                    break;
                case 2:
                    t.arrY = 5;
                    t.arrX = x + 2;
                    array[z][5][x + 2] = t;
                    break;
                case 3:
                    if(x == 1)
                    {
                        t.arrY = 4;
                        t.arrX = x;
                        array[z][4][x] = t;
                    }
                    else
                    {
                        t.arrY = 4;
                        t.arrX = x;
                        array[z][4][x] = t;
                    }
                    break;
                case 4:
                    if(x == 13)
                    {
                        t.arrY = 3;
                        t.arrX = 14;
                        array[z][3][14] = t;
                    }
                    else if(x == 14)
                    {
                        t.arrY = 3;
                        t.arrX = 15;
                        array[z][3][15] = t;
                    }
                    else
                    {
                        t.arrY = 3;
                        t.arrX = x + 1;
                        array[z][3][x + 1] = t;
                    }
                    break;
                case 5:
                    t.arrY = 2;
                    t.arrX = x + 2;
                    array[z][2][x + 2] = t;
                    break;
                case 6:
                    t.arrY = 1;
                    t.arrX = x + 3;
                    array[z][1][x + 3] = t;
                    break;
                case 7:
                    t.arrY = 0;
                    t.arrX = x + 1;
                    array[z][0][x + 1] = t;
                    break;
            }
        }
    }
    
    public static void positionTile(Tile t, int z, int y, int x)
    {
    	t.LAYER = z;
    	//special case top tile Layer 4
        if(z == 4)                  
        {
            t.ROW = 200;
            t.COLUMN = 650;
        }
        // Layer 3
        else if(z == 3)
        {
           t.ROW = 260 - (y * 76);
           t.COLUMN = 590 + (x * 75);
        }
        // Layer 2
        else if(z == 2)
        {
            t.ROW = 380 - (y * 76);
            t.COLUMN = 490 + (x * 75);
        }
     // Layer 1
        else if(z == 1)
        {
            t.ROW = 502 - (y * 76);
            t.COLUMN = 390 + (x * 75);
        }
        // Layer 0
        else                
        {
            switch(y)
            {
                case 0:
                    t.ROW = 622 - (y * 87);
                    t.COLUMN = 140 + (x * 75);
                    break;

                case 1:
                    t.ROW = 633 - (y * 87);
                    t.COLUMN = 290 + (x * 75);
                    break;

                case 2:
                    t.ROW = 644 - (y * 87);
                    t.COLUMN = 216 + (x * 75);
                    break;

                case 3:
                	//Left Alone piece 
                    if(x == 0)
                    {
                        t.ROW = 370;
                        t.COLUMN = 64;
                    }
                    else
                    {
                        t.ROW = 655 - (y * 87);
                        t.COLUMN = 65 + (x * 75);
                    }
                    break;

                case 4:
                	//Right Side First piece on end
                    if(x == 12)
                    {
                        t.ROW = 360;
                        t.COLUMN = 1041;
                    }
                    else if(x == 13)
                    {
                        t.ROW = 360;
                        t.COLUMN = 1111;
                    }
                    //The whole Column 4 
                    else
                    {
                        t.ROW = 666 - (y * 87);
                        t.COLUMN = 140 + (x * 75);
                    }
                    break;

                case 5:
                    t.ROW = 678 - (y * 87);
                    t.COLUMN = 216 + (x * 75);
                    break;

                case 6:
                    t.ROW = 689 - (y * 87);
                    t.COLUMN = 290 + (x * 75);
                    break;

                case 7:
                    t.ROW = 700 - (y * 87);
                    t.COLUMN = 140 + (x * 75);
                    break;

                default:
                    break;
            }
        }
    }
    
    public boolean isTileOpen(Tile t)
    {
        if(t.arrZ == 4)
            return true;
        else if(t.arrZ == 3 && (array[4][3][7]) != null)
            return false;
        else if((t.arrZ == 0 && t.arrY == 4 && t.arrX == 2) && (array[0][4][1] != null))
            return false;
        else if((t.arrZ == 0 && t.arrY == 3 && t.arrX == 2) && (array[0][4][1] != null))
            return false;
        else if((t.arrZ == 0 && t.arrY == 4 && t.arrX == 13) && (array[0][3][14] != null))
            return false;
        else if((t.arrZ == 0 && t.arrY == 3 && t.arrX == 13) && (array[0][3][14] != null))
            return false;
        else if(array[t.arrZ + 1][t.arrY][t.arrX] == null && (array[t.arrZ][t.arrY][t.arrX - 1] == null ||
            array[t.arrZ][t.arrY][t.arrX + 1] == null))
            return true;
        return false;
    }

    public void removeArrElement(int x, int y, int z)
    {
        array[z][y][x] = null;
    }
    
    public void addArrElement(Tile t)
    {
    	array[t.arrZ][t.arrY][t.arrX] = t;
    }

    public Tile[][][] getArray() 
    {
    	return array;
    }

    public ArrayList<Tile> getTiles()
    {
        return tiles;
    }
    
}
