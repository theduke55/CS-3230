import java.awt.*;
import java.net.URL;

import javax.swing.*;

public class FlowerTile extends PictureTile
{
	private ImageIcon image; 
	
	public FlowerTile(String name)
	{
		super(name);
		
		switch(name)
		{
			case "Chrysanthemum" : 
				 URL url = MahJong.class.getResource("images/Chrysanthemum.png");
		         image = new ImageIcon(url);
				break;
			case "Orchid" : 
				 URL url1 = MahJong.class.getResource("images/Orchid.png");
		         image = new ImageIcon(url1);
				break;
			case "Plum" :
				 URL url2 = MahJong.class.getResource("images/Plum.png");
		         image = new ImageIcon(url2);
				break;
			case "Bamboo" : 
				URL url3 = MahJong.class.getResource("images/Bamboo.png");
		        image = new ImageIcon(url3);
				break;
		}
		
		setToolTipText(toString());
	}
	
	@Override 
	public void paintComponent(Graphics g)
	{
		
		super.paintComponent(g);
		
		g.drawImage(image.getImage(), 35, 10, this);
	
	}
	
	public static void main(String[] args)
	{
		JFrame	frame = new JFrame();

		frame.setLayout(new FlowLayout());
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Flower Tiles");

		frame.add(new FlowerTile("Chrysanthemum"));
		frame.add(new FlowerTile("Orchid"));
		frame.add(new FlowerTile("Plum"));
		frame.add(new FlowerTile("Bamboo"));

		frame.pack();
		frame.setVisible(true);
	}
}
