import java.awt.*;
import javax.swing.*;

public class CharacterTile extends Tile
{
	protected char symbol; 
	private char[] wan =
	{
        //Unicode, array[i], array element data
		'\u4E00',   //(0) 1
		'\u4E8C',   //(1) 2
		'\u4E09',   //(2) 3
		'\u56DB',   //(3) 4
		'\u4E94',   //(4) 5
		'\u516D',   //(5) 6
		'\u4E03',   //(6) 7
		'\u516B',   //(7) 8
		'\u4E5D',   //(8) 9
		'\u5317',   //(9) North
		'\u6771',   //(10) East
		'\u897F',   //(11) West
		'\u5357',   //(12) South
		'\u4E2D',   //(13) Red Dragon
		'\u767C',   //(14) Green Dragon
  };
	
	public CharacterTile(char symbol)
	{
		this.symbol = symbol;
		setToolTipText(toString());
		
	}
	
	@Override public void paintComponent(Graphics g)
    {
        super.paintComponent(g);  
        
        Graphics2D g2 = (Graphics2D) g;
        g2.setFont(new Font("Sans Serif", Font.PLAIN, 14));
        g2.setColor(Color.RED);

        // Coordinates of small symbol
        g2.drawString(Character.toString(symbol), 85, 15); 

        //determines which method to call (number or letter)
        if(symbol < 58)        
            paintNum(g2);
        else
            paintLetter(g2);

    }

    public void paintNum(Graphics2D g2)
    {
        g2.setFont(new Font("MS Song", Font.PLAIN, 30));
        g2.setColor(Color.BLACK);
        g2.drawString(Character.toString(wan[Integer.parseInt(Character.toString(symbol)) - 1]), 45,30);

        // Prints chinese symbol 'wan'
        g2.setColor(Color.decode("#ff3500"));
        g2.drawString("\u842C",45,65);
    }

    public void paintLetter(Graphics g2)
    {
        g2.setFont(new Font("MS Song", Font.PLAIN, 50));
        if(symbol == 'N' || symbol == 'E' || symbol == 'S' || symbol == 'W')
            g2.setColor(Color.BLACK);
        else if(symbol == 'C')
            g2.setColor(Color.decode("#ff3500"));//Red Dragon 
        else
            g2.setColor(Color.GREEN);
        g2.drawString(Character.toString(wan[indexLocation(symbol)]),35, 55);
    }

    private int indexLocation(char s)
    {
        int location = 9;
        switch(s)
        {
            case 'N': location = 9;
            break;
            case 'E': location = 10;
            break;
            case 'W': location = 11;
            break;
            case 'S': location = 12;
            break;
            case 'C': location = 13;
            break;
            case 'F': location = 14;
            break;
        }
        return location;
    }
		
	@Override public boolean matches(Tile other)
	{
		super.matches(other); 
		
		CharacterTile ct = (CharacterTile)other; 
		if (ct.symbol == symbol)
		{
			return true; 
		}
		else
		{
			return false; 
		}
	}
	
	@Override public String toString()
	{
		String t = ""; 
		switch(symbol)
		{
			case '1':
			case '2': 
			case '3':
			case '4': 
			case '5': 
			case '6': 
			case '7': 
			case '8': 
			case '9': 
				t = "Character " + symbol; 
				break;  
			case 'N':
				t = "North Wind"; 
				break;
			case 'E': 
				t = "East Wind";
				break;
			case 'W': 
				t = "West Wind";
				break;
			case 'S': 
				t = "South Wind";
				break;
			case 'C': 
				t = "Red Dragon";
				break;
			default: 
			case 'F': 
				t = "Green Dragon";
				break;
		}
		
		return t; 
	}
	
	public static void main(String[] args)
	{
		JFrame		frame = new JFrame();
		JPanel		tiles = new JPanel();
		JScrollPane	scroller = new JScrollPane(tiles);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setTitle("Character Tiles");
		frame.add(scroller);

		// Try something like this if your tiles don't fit on the screen.
		// Replace "tile width" and "tile height" with your values.
		//scroller.setPreferredSize(new Dimension(8 * tile width, 40 + tile height));

		tiles.add(new CharacterTile('1'));
		tiles.add(new CharacterTile('2'));
		tiles.add(new CharacterTile('3'));
		tiles.add(new CharacterTile('4'));
		tiles.add(new CharacterTile('5'));
		tiles.add(new CharacterTile('6'));
		tiles.add(new CharacterTile('7'));
		tiles.add(new CharacterTile('8'));
		tiles.add(new CharacterTile('9'));
		tiles.add(new CharacterTile('N'));
		tiles.add(new CharacterTile('E'));
		tiles.add(new CharacterTile('W'));
		tiles.add(new CharacterTile('S'));
		tiles.add(new CharacterTile('C'));
		tiles.add(new CharacterTile('F'));

		frame.pack();
		frame.setVisible(true);
	}
}




