package checkisbn;

import java.util.Scanner;

/**
 * @author: Trevor Barker
 * @DueDate: 05/19/2018
 * @Description: The user will input a string of 12 digits and the program will calculate the ISBN
 */
public class CheckISBN {

    // main method
    public static void main(String[] args) {
        String userInput;           // users 12 digit string
        boolean validInput = true;  // error checking variable
        int digit13 = 0;            // ISBN check digit
        
        Scanner input = new Scanner(System.in);

        do {
            // Collect user input into a string
            System.out.print("Enter the first 12 digits of an ISBN-13 as a string: ");
            userInput = input.nextLine();
            
            // set error checking variable to true "no errors"
            validInput = true;
            
            // Display error prompt if the length is not 12 digits or for non-numbers
            if (userInput.length() != 12 || !userInput.matches("[0-9]+")){
                System.out.println("Invalid input.");
                validInput = false;
            }
        } while (!validInput);

        // Cast the string of characters to integers and perform math functions
        for (int i = 0; i < 12; i++){
            // for all odd digits add them to the checksum
            if (i%2 == 0){
                digit13 += Integer.parseInt(String.valueOf(userInput.charAt(i)));
            }
            // for all even digits, multiply the digit by 3 and then add it to the checksum
            else{
                digit13 += (3 * Integer.parseInt(String.valueOf(userInput.charAt(i))));
            }
        } // end of for loop
        
        // Calculate the ISBN using the given formula
        digit13 = 10 - digit13%10;
        
        // If the checksum is 10, replace it with a 0
        if (digit13 == 10){
            digit13 = 0;
        }
        
        // Print out the ISBN
        System.out.println("The ISBN-13 is: " + userInput + digit13);
    }

}
