/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CardGame;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;


/**
 *
 * @author Trevor
 */
public class DisplayFourCardsWithRefresh extends Application {

    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage primaryStage){
        FlowPane hbox = new FlowPane();
        
        hbox.setAlignment(Pos.CENTER);
        refreshPage(hbox);
        
        //Set title
        primaryStage.setTitle("Display Four Cards with Refresh");
        
        //Create scene
        Scene scene = new Scene(hbox, 300, 150);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void refreshPage(FlowPane pane) {
        pane.getChildren().clear();
        
        Deck deck = new Deck();
        deck.Shuffle();
        
        Image card;

        //Loop through three times and display the cards image to the hbox
        for (int i = 0; i < 4; i++) {
            int value = (deck.cards.get(i).getRankValue() + deck.cards.get(i).getSuitValue());
            card = new Image("image/" + value + ".png");
            pane.getChildren().add(new ImageView(card));
        }
        
        Button refresh = new Button("Refresh");
        refresh.setOnAction(e -> refreshPage(pane));
        pane.getChildren().add(refresh);
    }
}
