package CardGame;

import java.util.ArrayList;
import java.util.Collections;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Trevor
 */
public class Hand extends GroupOfCards{
    
    Hand(){
        super();
    }
    
    public Hand orderHand(Hand playerHand){
        Collections.sort(playerHand.cards);
        return playerHand;
    }
}
                  