
public class Bamboo1Tile extends PictureTile{

	// Constructor
	public Bamboo1Tile() {
		super("Sparrow");
	}

	public String toString() {
		return "Bamboo 1";
	}
}
