
public class CharacterTile extends Tile{
	// Class variables
	protected char symbol;
	
	// Constructor
	public CharacterTile(char symbol) {
		this.symbol = symbol;
	}
	
	public boolean matches(Tile other) {
		// Call the matches method from the Tile class
		if(super.matches(other)) {
			// Create a test object from casting CharacterTile
			CharacterTile test = (CharacterTile)other;
			return test.symbol == this.symbol;
		}
		else {
			return false;
		}
	}
	
	public String toString() {
		if(this.symbol == '1') {
			return "Character 1";
		}
		else if(this.symbol == '2') {
			return "Character 2";
		}
		else if(this.symbol == '3') {
			return "Character 3";
		}
		else if(this.symbol == '4') {
			return "Character 4";
		}
		else if(this.symbol == '5') {
			return "Character 5";
		}
		else if(this.symbol == '6') {
			return "Character 6";
		}
		else if(this.symbol == '7') {
			return "Character 7";
		}
		else if(this.symbol == '8') {
			return "Character 8";
		}
		else if(this.symbol == '9') {
			return "Character 9";
		}
		else if(this.symbol == 'N') {
			return "North Wind";
		}
		else if(this.symbol == 'E') {
			return "East Wind";
		}
		else if(this.symbol == 'W') {
			return "West Wind";
		}
		else if(this.symbol == 'S') {
			return "South Wind";
		}
		else if(this.symbol == 'C') {
			return "Red Dragon";
		}
		else if(this.symbol == 'F') {
			return "Green Dragon";
		}
		else {
			return "Invalid symbol";
		}
	}
}
