
public class CircleTile extends RankTile{
	
	// Constructor
	public CircleTile(int rank) {
		super(rank);
	}
	
	public String toString() {
		if(this.rank == 1) {
			return "Circle 1";
		}
		else if(this.rank == 2) {
			return "Circle 2";
		}
		else if(this.rank == 3) {
			return "Circle 3";
		}
		else if(this.rank == 4) {
			return "Circle 4";
		}
		else if(this.rank == 5) {
			return "Circle 5";
		}
		else if(this.rank == 6) {
			return "Circle 6";
		}
		else if(this.rank == 7) {
			return "Circle 7";
		}
		else if(this.rank == 8) {
			return "Circle 8";
		}
		else if(this.rank == 9) {
			return "Circle 9";
		}
		else {
			return "Invalid rank";
		}
	}
}
