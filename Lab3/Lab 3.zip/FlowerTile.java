
public class FlowerTile extends PictureTile{

	// Constructor
	public FlowerTile(String name) {
		super(name);
	}

}
