
public abstract class RankTile extends Tile{
	// Class variables
	protected int rank;
	
	// Constructor
	public RankTile(int rank) {
		this.rank = rank;
	}
	
	public boolean matches(Tile other) {
		// Call the matches method in the Tile class
		if(super.matches(other)) {
			// Create a test object by casting RankTile
			RankTile test = (RankTile)other;
			return test.rank == this.rank;
		}
		else {
			return false;
		}
	}
}
